<?php
if (!isset($_SESSION)) {
    session_start();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $alamat = $_POST['alamat'];
    $no_ktp = $_POST['no_ktp'];
    $no_hp = $_POST['no_hp'];

    if ($password === $confirm_password) {
        $query = "SELECT * FROM pasien WHERE nama ='$nama'";
        $result = $mysqli->query($query);
        if ($result === false) {
            die("Query error: " . $mysqli->error);
        }

        if ($result->num_rows == 0) {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Query untuk mendapatkan nomor pendaftaran tertinggi
            $query_max_pendaftaran = "SELECT MAX(CAST(SUBSTRING(no_rm, 8) AS SIGNED)) as max_pendaftaran FROM pasien";
            $result_max_pendaftaran = $mysqli->query($query_max_pendaftaran);

            if ($result_max_pendaftaran === false) {
                die("Query error: " . $mysqli->error);
            }

            $row_max_pendaftaran = $result_max_pendaftaran->fetch_assoc();
            $max_pendaftaran = $row_max_pendaftaran['max_pendaftaran'];
            $nomor_pendaftaran = $max_pendaftaran + 1;

            // Format nomor pendaftaran ke dalam format yang diinginkan
            $no_rm = date('Ym') . '-' . sprintf('%03d', $nomor_pendaftaran);

            // Insert data ke dalam tabel
            $insert_query = "INSERT INTO pasien (nama, password, alamat, no_ktp, no_hp, no_rm) 
                            VALUES ('$nama', '$hashed_password', '$alamat', '$no_ktp', '$no_hp', '$no_rm')";

            if (mysqli_query($mysqli, $insert_query)) {
                echo "<script>
                alert('Pendaftaran Berhasil'); 
                document.location='index.php?page=loginPasien';
                </script>";
            } else {
                $error = "Pendaftaran gagal";
            }
        } else {
            $error = "Username sudah digunakan";
        }
    } else {
        $error = "Password tidak cocok";
    }
}
?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header text-center" style="font-weight: bold; font-size: 32px;">Register</div>
                <div class="card-body">
                    <form method="POST" action="index.php?page=registerPasien">
                        <?php
                        if (isset($error)) {
                            echo '<div class="alert alert-danger">' . $error . '
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    </div>';
                        }
                        ?>
                        <div class="form-group">
                            <label for="nama">Nama</label>
                            <input type="text" name="nama" class="form-control" required placeholder="Masukkan nama anda">
                        </div>
                        <div class="form-group">
                            <label for="alamat">Alamat</label>
                            <input type="text" name="alamat" class="form-control" required placeholder="Masukkan alamat anda">
                        </div>                        
                        <div class="form-group">
                            <label for="no_ktp">No KTP</label>
                            <input type="text" name="no_ktp" class="form-control" required placeholder="Masukkan nomor KTP">
                        </div>
                        <div class="form-group">
                            <label for="no_hp">Nomor HP</label>
                            <input type="text" name="no_hp" class="form-control" required placeholder="Masukkan nomor HP">
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" name="password" class="form-control" required placeholder="Masukkan password">
                        </div>
                        <div class="form-group">
                            <label for="confirm_password">Confirm Password</label>
                            <input type="password" name="confirm_password" class="form-control" required placeholder="Masukkan password konfirmasi">
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary btn-block">Register</button>
                        </div>
                    </form>
                    <div class="text-center">
                        <p class="mt-3">Sudah Punya Akun? <a href="index.php?page=loginPasien">Login</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
