<?php
if (!isset($_SESSION)) {
    session_start();
}

// Gantilah ini dengan metode otentikasi yang sesuai di aplikasi web Anda
// Misalnya, jika Anda menyimpan No RM di sesi setelah login, Anda dapat mengambilnya seperti ini:
if (isset($_SESSION['nama'])) {
    $namaPasien = $_SESSION['nama'];

    // Query untuk mendapatkan no_rm dan id_pasien berdasarkan nama
    $queryNoRM = "SELECT id, no_rm FROM pasien WHERE nama = ?";
    $stmtNoRM = $mysqli->prepare($queryNoRM);
    $stmtNoRM->bind_param("s", $namaPasien);

    if ($stmtNoRM->execute()) {
        $resultNoRM = $stmtNoRM->get_result();

        if ($resultNoRM->num_rows > 0) {
            $rowNoRM = $resultNoRM->fetch_assoc();
            $currentNoRM = $rowNoRM['no_rm'];
            $idPasien = $rowNoRM['id'];

            // Set $_SESSION['no_rm']
            $_SESSION['no_rm'] = $currentNoRM;
        } else {
            // Handle case when No RM is not available (redirect or display an error message)
            // For now, let's set them to empty values
            $currentNoRM = '';
            $idPasien = '';
        }
    } else {
        // Handle error
        die("Query failed: " . $stmtNoRM->error);
    }

    $stmtNoRM->close();
} else {
    // Handle case when No RM is not available (redirect or display an error message)
    // For now, let's set them to empty values
    $currentNoRM = '';
    $idPasien = '';
}

ob_start();

// Include the database connection file (koneksi.php)
include_once("koneksi.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_poli'])) {
    $newPoli = $_POST['add_poli'];
    $newJadwalId = $_POST['add_jadwal'];
    $newKeluhan = $_POST['add_keluhan'];

    // Fetching the last no_antrian
    $queryLastNoAntrian = "SELECT MAX(no_antrian) AS last_no_antrian FROM daftar_poli";
    $resultLastNoAntrian = $mysqli->query($queryLastNoAntrian);

    if (!$resultLastNoAntrian) {
        die("Query failed: " . $mysqli->error);
    }

    $lastNoAntrian = ($resultLastNoAntrian->num_rows > 0) ? $resultLastNoAntrian->fetch_assoc()['last_no_antrian'] : 0;
    $newNoAntrian = $lastNoAntrian + 1;

    // Default status_periksa
    $defaultStatusPeriksa = 0;

    // Check if 'no_rm' is set in session
    if (isset($_SESSION['no_rm'])) {
        // Get id_pasien based on no_rm
        $queryIdPasien = "SELECT id FROM pasien WHERE no_rm = ?";
        $stmtIdPasien = $mysqli->prepare($queryIdPasien);
        $stmtIdPasien->bind_param("s", $_SESSION['no_rm']);

        if ($stmtIdPasien->execute()) {
            $resultIdPasien = $stmtIdPasien->get_result();

            if ($resultIdPasien->num_rows > 0) {
                $rowIdPasien = $resultIdPasien->fetch_assoc();
                $idPasien = $rowIdPasien['id'];

                // Insert new data into the database using prepared statement
                $insertQuery = "INSERT INTO daftar_poli (id_pasien, id_jadwal, keluhan, no_antrian, status_periksa) VALUES (?, ?, ?, ?, ?)";
                $stmt = $mysqli->prepare($insertQuery);

                if (!$stmt) {
                    die("Error: " . $mysqli->error);
                }

                // Bind parameters
                $bindResult = $stmt->bind_param("ssdsd", $idPasien, $newJadwalId, $newKeluhan, $newNoAntrian, $defaultStatusPeriksa);

                if (!$bindResult) {
                    die("Binding parameters failed: " . $stmt->error);
                }

                // Execute the statement
                $executeResult = $stmt->execute();

                if (!$executeResult) {
                    die("Execution failed: " . $stmt->error);
                }

                // Insertion successful, close the statement
                $stmt->close();

                // Redirect to the desired location
                header("Location: menuperiksaPasien.php");
                exit();
            } else {
                // Handle case when No RM is not found in the pasien table
                die("No RM not found in the pasien table");
            }
        } else {
            // Handle error
            die("Query failed: " . $stmtIdPasien->error);
        }
    } else {
        // Handle case when 'no_rm' is not set in session
        die("No RM not set in session");
    }
}

// Fetch data for the main table
$queryMainTable = "SELECT pasien.no_rm, daftar_poli.id AS poli_id, jadwal_periksa.id AS jadwal_id, jadwal_periksa.hari, jadwal_periksa.jam_mulai, jadwal_periksa.jam_selesai, poli.nama_poli, daftar_poli.keluhan
                  FROM pasien
                  JOIN daftar_poli ON pasien.id = daftar_poli.id_pasien
                  JOIN jadwal_periksa ON daftar_poli.id_jadwal = jadwal_periksa.id
                  JOIN dokter ON jadwal_periksa.id_dokter = dokter.id
                  JOIN poli ON dokter.id_poli = poli.id";

$resultMainTable = $mysqli->query($queryMainTable);

// Tambahkan penanganan kesalahan
if (!$resultMainTable) {
    die("Query failed: " . $mysqli->error);
}

// Fetch the data for the main table as an associative array
$dataMainTable = $resultMainTable->fetch_all(MYSQLI_ASSOC);

// Fetch data for the select options
$querySelectOptions = "SELECT id, nama_poli FROM poli";
$resultSelectOptions = $mysqli->query($querySelectOptions);

// Tambahkan penanganan kesalahan
if (!$resultSelectOptions) {
    die("Query failed: " . $mysqli->error);
}

// Fetch the data for select options as an associative array
$dataSelectOptions = $resultSelectOptions->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Add your head section here -->

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.6.0/css/bootstrap.min.css">

    <!-- Add other necessary CSS links here -->
</head>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#addModal">Tambah Poli</button>

                                <table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>No RM</th>
                                            <th>Poli</th>
                                            <th>Jadwal</th>
                                            <th>Keluhan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $counter = 1; // Variabel penanda nomor urut
                                        foreach ($dataMainTable as $row) {
                                            echo "<tr>";
                                            echo "<td>" . $counter . "</td>"; // Gunakan counter sebagai nomor urut
                                            $counter++; // Tingkatkan counter setiap kali loop
                                            echo "<td>" . $row['no_rm'] . "</td>";
                                            echo "<td>" . $row['nama_poli'] . "</td>"; // Akses kunci yang benar untuk poli (nama_poli)
                                            echo "<td>" . $row['hari'] . " " . $row['jam_mulai'] . " - " . $row['jam_selesai'] . "</td>"; // Gabungkan hari, jam_mulai, dan jam_selesai untuk jadwal
                                            echo "<td>" . $row['keluhan'] . "</td>";
                                            echo "</tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- Modal for adding poli -->
    <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addModalLabel">Tambah Poli</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="menuperiksaPasien.php">
                        <!-- Replace with the actual add PHP file -->
                        <div class="form-group">
                            <label for="add_no_rm">No RM</label>
                            <input type="text" class="form-control" id="add_no_rm" name="add_no_rm" value="<?php echo $currentNoRM; ?>" required readonly>
                        </div>
                        <div class="form-group">
                            <label for="add_poli">Pilih Poli</label>
                            <select class="form-control" id="add_poli" name="add_poli" required>
                                <?php
                                // Use the separate data for select options
                                foreach ($dataSelectOptions as $row) {
                                    echo "<option value='" . $row['nama_poli'] . "'>" . $row['nama_poli'] . "</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="add_jadwal">Jadwal</label>
                            <select class="form-control" id="add_jadwal" name="add_jadwal" required>
                                <?php
                                // Ambil opsi jadwal dari database dan tampilkan sebagai opsi dalam elemen select
                                $jadwalOptions = array(); // Inisialisasi array untuk menampung opsi jadwal unik
                                foreach ($dataMainTable as $row) {
                                    // Gabungkan hari, jam_mulai, dan jam_selesai untuk membuat string jadwal
                                    $jadwal = $row['hari'] . " " . $row['jam_mulai'] . " - " . $row['jam_selesai'];

                                    // Tambahkan jadwal ke dalam array jika belum ada
                                    if (!in_array($jadwal, $jadwalOptions)) {
                                        $jadwalOptions[] = $jadwal;
                                        echo "<option value='" . $row['jadwal_id'] . "'>" . $jadwal . "</option>";
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="add_keluhan">Keluhan</label>
                            <textarea class="form-control" id="add_keluhan" name="add_keluhan" rows="3"></textarea>
                        </div>
                        <button type="submit" name="add_poli" class="btn btn-primary">Tambah</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.6.0/js/bootstrap.min.js"></script>

    <!-- Add other necessary script includes here -->
</body>

</html>
